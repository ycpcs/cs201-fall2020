public class Q9 {
	// IMPORTANT: you MUST use recursion to implement this method.
	// Do not use a loop.
	public static int countTall(String s) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
