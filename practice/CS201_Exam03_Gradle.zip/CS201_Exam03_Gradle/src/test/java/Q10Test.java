import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class Q10Test {
	private Stats stats;
	
	@Before
	public void setUp() {
		stats = Q10.readStats();
	}
	
	@Test
	public void testGetRunsByPlayer() throws Exception {
		assertEquals(10, stats.getRunsForPlayer("Tracy"));
		assertEquals(14, stats.getRunsForPlayer("Dianna"));
		assertEquals(13, stats.getRunsForPlayer("Lyle"));
		assertEquals(6, stats.getRunsForPlayer("Elena"));
		assertEquals(15, stats.getRunsForPlayer("Jean"));
		assertEquals(16, stats.getRunsForPlayer("Gertrude"));
		assertEquals(13, stats.getRunsForPlayer("Zachary"));
		assertEquals(11, stats.getRunsForPlayer("Linda"));
		assertEquals(8, stats.getRunsForPlayer("Patricia"));
		assertEquals(13, stats.getRunsForPlayer("Felix"));
	}
	
	@Test
	public void testGetRunsByGame() throws Exception {
		assertEquals(10, stats.getRunsForGame(1));
		assertEquals(12, stats.getRunsForGame(2));
		assertEquals(4, stats.getRunsForGame(3));
		assertEquals(3, stats.getRunsForGame(4));
		assertEquals(17, stats.getRunsForGame(5));
		assertEquals(6, stats.getRunsForGame(6));
		assertEquals(20, stats.getRunsForGame(7));
		assertEquals(17, stats.getRunsForGame(8));
		assertEquals(12, stats.getRunsForGame(9));
		assertEquals(18, stats.getRunsForGame(10));
	}
}
