public class Coins {
	// TODO: add fields here

	// TODO: add constructors
	
	// TODO: add methods
}
