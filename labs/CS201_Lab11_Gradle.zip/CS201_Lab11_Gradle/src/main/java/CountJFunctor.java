public class CountJFunctor implements Functor<String> {
	// TODO: field(s)
	
	public CountJFunctor() {
		// TODO: initialize field(s)
	}

	@Override
	public void apply(String value) {
		throw new UnsupportedOperationException("TODO - implement");
	}

	/**
	 * @return the total number of 'J' or 'j' characters contained
	 *         in all of the String values seen by this functor
	 */
	public int getJCount() {
		throw new UnsupportedOperationException("TODO - implement");
	}

}
